import json
import asyncio
import os
import re
import requests
import discord
from discord.ext import commands

bot = commands.Bot(command_prefix='.', intents=discord.Intents.all())
bot.remove_command('help')

@bot.event
async def on_ready():
    print(f"Logged in as: {bot.user.name} ({bot.user.id})")
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.playing, name=".help"))

async def update_balance(webhook_message):
    with open('database.json', 'r') as f:
        data = json.load(f)

        if not webhook_message.content:
            return

        growIdMatch = re.search(r'GrowID: (\S+)', webhook_message.content)
        depositMatch = re.search(r'Deposit: (\d+) (World Lock|Diamond Lock)', webhook_message.content)

        if growIdMatch and depositMatch:
            growId = growIdMatch.group(1)
            deposit = int(depositMatch.group(1))
            if depositMatch.group(2) == 'Diamond Lock':
                deposit *= 100

            user_found = False
            for user in data:
                if user['name'] == growId:
                    user['balance'] += deposit
                    with open('database.json', 'w') as f:
                        json.dump(data, f)
                    await webhook_message.channel.send(f"Balance for user **{growId}** updated to **{user['balance']}**")
                    user_found = True
                    break

            if not user_found:
                await webhook_message.channel.send("User not found in database")

@bot.event
async def on_message(message):
    if message.channel.id == 1085897910463508540 and message.webhook_id: #ganti channel id tempat webhook donation log
        await update_balance(message)

    await bot.process_commands(message)

@bot.command()
async def help(ctx):
    if ctx.author.id == 687909626456571955: # ganti dengan owner id lu
        message = ".help\n.set <growid>\n.bal\n.depo\n.info\n.stock\n.buy <code product> <amount>\n\n.addbal <tag user> <jumlah balance>\n.send <@mention> <code> <amount>\n.addp <nama produk> <code> <harga> <id role>\n.adds <code produk> <cid/lisensi/rdp>\n.remove <code produk>\n.changeprice <code> <price>\n.changeworld <world> <owner>"
    else:
        message = ".help\n.set <growid>\n.bal\n.depo\n.info\n.stock\n.buy <code product> <amount>"
    embed = discord.Embed(title="Bot Commands", color=discord.Color.green())
    embed.description = message
    await ctx.reply(embed=embed)

@bot.command()
async def set(ctx, name):
    user_balance = 0
    user_id = ctx.author.id

    try:
        with open('database.json') as f:
            database = json.load(f)
    except (FileNotFoundError, json.decoder.JSONDecodeError):

        with open('database.json', 'w') as f:
            json.dump([], f)
        database = []

    if any(user['name'] == name for user in database if user['user'] != user_id):
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"Name `{name}` is already in use by another user.\nPlease choose a different name."
        await ctx.reply(embed=embed)
        return


    user_index = next((i for i, user in enumerate(database) if user['user'] == user_id), -1)
    if user_index != -1:

        database[user_index]['name'] = name
    else:

        database.append({'user': user_id, 'name': name, 'balance': user_balance})

    with open('database.json', 'w') as f:
        json.dump(database, f)

        embed = discord.Embed(title="Success", color=discord.Color.green())
        embed.description = f"Your GrowID has been set to: {name}"
        await ctx.reply(embed=embed)

@bot.command()
async def bal(ctx):
    user_id = ctx.author.id

    with open('database.json', 'r') as f:
        data = json.load(f)

    user = next((user for user in data if user['user'] == user_id), None)
    if user is None:
        return await ctx.reply(f"You don't have an account yet. Please `/set <name>` first.")

    name = user['name']
    balance = user['balance']

    embed = discord.Embed(title=f"Your Balance is {balance} <:emoji_9:1071815138430160997>", color=discord.Color.green())

    await ctx.reply(embed=embed)

@bot.command()
async def info(ctx, member: discord.Member = None):
    if not member:
        member = ctx.author
    
    with open('database.json', 'r') as f:
        data = json.load(f)

    name = None
    balance = None

    for item in data:
        if item['user'] == member.id:
            name = item['name']
            balance = item['balance']
            break
    
    if name is None or balance is None:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"User {member.mention} not found in database."
        await ctx.reply(embed=embed)
    else:
        embed = discord.Embed(title=f"{member.display_name} Information", color=discord.Color.green())
        embed.description = f"<a:oemji:1085835206973460480>GrowID: {name}\n<a:oemji:1085835206973460480>Balance: {balance} <:emoji_9:1071815138430160997>"
        await ctx.reply(embed=embed)

@bot.command()
async def wb(ctx, *, text):
    webhook_url = "https://discord.com/api/webhooks/1094481560939528212/9ntgtRJadY2V9iF0tlggDqi2vRxY6EZAZOtXcg_J9mHOpgFPLo5KbfLaj_sM1USXNMoC"
    data = {"content": text}
    response = requests.post(webhook_url, json=data)
    if response.status_code == 204:
        await ctx.reply("Teks berhasil dikirim ke webhook.")
    else:
        await ctx.reply("Tidak dapat mengirim teks ke webhook.")

@bot.command()
async def addp(ctx, *args):
    if ctx.author.id != 687909626456571955: # ganti dengan owner id lu
        await ctx.reply("You do not have permission to use this command.")
        return
    
    name = " ".join(args[:-3]) # Mengubah jumlah argumen yang diambil
    code = args[-3]
    price = args[-2]
    role_id = args[-1] # Menambahkan argumen untuk ID role
    stock = ""

    with open("sell.json", "r") as f:
        data = json.load(f)
    
    new_product = {
        "name": name,
        "code": code,
        "price": price,
        "role": role_id, # Menambahkan data ID role
        "stock": stock
    }
    
    data.append(new_product)
    
    with open("sell.json", "w") as f:
        json.dump(data, f)
    
        embed = discord.Embed(title="Success", color=discord.Color.green())
        embed.description = f"Successfully added the product"
        await ctx.reply(embed=embed)

@bot.command()
async def remove(ctx, code: str):
    if ctx.author.id != 687909626456571955: # ganti dengan owner id lu
        await ctx.reply("You do not have permission to use this command.")
        return

    with open("sell.json", "r") as f:
        data = json.load(f)
    
    for i in range(len(data)):
        if data[i]["code"] == code:
            del data[i]
            break
    else:

        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"There are no products with code {code}"
        await ctx.reply(embed=embed)
        return
    
    with open("sell.json", "w") as f:
        json.dump(data, f, indent=4)
    
    embed = discord.Embed(title="Success", color=discord.Color.green())
    embed.description = f"Product with code {code} was deleted"
    await ctx.reply(embed=embed)

@bot.command()
async def adds(ctx, code: str, *args):
    if ctx.author.id != 687909626456571955: # ganti dengan owner id lu
        await ctx.reply("You do not have permission to use this command.")
        return
    data = ", ".join(args)

    with open("sell.json", "r+") as f:
        products = json.load(f)

        for product in products:
            if product["code"] == code:
                if product["stock"] == "":
                    product["stock"] = data
                else:
                    product["stock"] = ", ".join([product["stock"], data])
                break
        else:
            embed = discord.Embed(title="Error", color=discord.Color.red())
            embed.description = f"No products found with code {code}"
            await ctx.reply(embed=embed)
            return

        f.seek(0)
        json.dump(products, f, indent=4)
        f.truncate()

        embed = discord.Embed(title="Success", color=discord.Color.green())
        embed.description = f"Stock has been added to the product with code {code}"
        await ctx.reply(embed=embed)


@bot.command()
async def buy(ctx, code, quantity):
    # ganti 1069888817902927912 dengan id category channel ticket lu
    if ctx.channel.category_id != 1069888289575809056:
        # ganti #1071824012017152022 dengan channel tiket lu
        await ctx.send("Create Ticket in <#1069884636609646662> to use command!")
        return
    
    with open("sell.json", "r") as f:
        data = json.load(f)
    product = next((p for p in data if p["code"] == code), None)

    if product is None:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"No products found with code {code}"
        await ctx.reply(embed=embed)
        return

    try:
        quantity = int(quantity)
    except ValueError:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"The purchase amount must be a number\ex: .buy rdp 1"
        await ctx.reply(embed=embed)
        return

    stock = product["stock"].split(", ")
    if len(stock) < quantity:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"The product is out of stock"
        await ctx.reply(embed=embed)
        return
    elif not product["stock"]:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"The product is out of stock"
        await ctx.reply(embed=embed)
        return

    with open("database.json", "r") as f:
        db = json.load(f)
    user = next((u for u in db if u["user"] == ctx.author.id), None)

    if user is None:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"Please do .set <gowid> before purchasing"
        await ctx.reply(embed=embed)
        return

    price = int(product["price"])
    total_price = price * quantity

    if user["balance"] < total_price:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"Your balance is not enough"
        await ctx.reply(embed=embed)
        return

    with open("order.json", "r") as f:
        order_data = json.load(f)
        order_number = order_data["order_number"]
    order_number += 1
    order_data["order_number"] = order_number
    with open("order.json", "w") as f:
        json.dump(order_data, f)

    await ctx.reply("Please Wait!", delete_after=1.0)
    
    message = f"Here your {product['name']}:\n"
    message += "\n"
    message += '\n'.join([line.rstrip(',') for line in stock[:quantity]])
    message += "\n"

    filename = f"Arcexy Store.txt"
    with open(filename, "w") as f:

        f.write(message)

    with open(filename, "rb") as f:
        file = discord.File(f)
        embed = discord.Embed(
            title="Pembelian Berhasil",
            description=f"Anda telah membeli **{quantity} {product['name']}** seharga **{total_price}** <:emoji_9:1071815138430160997>\nJangan lupa untuk memberi reps, Terima Kasih.",
            color=discord.Color.green()
        )
        await ctx.author.send(embed=embed, file=file)
    
    # Memeriksa apakah pengguna telah memiliki role sebelumnya
    role_id = int(product["role"])  # Mengambil role ID dari sell.json
    role = ctx.guild.get_role(role_id)  # Mendapatkan role dari role ID
    if role is not None and role not in ctx.author.roles:
        # Menambahkan role jika pengguna belum memiliki role tersebut
        await ctx.author.add_roles(role)

        # Mengirim pesan konfirmasi ke user
        embed = discord.Embed(title="Role Added", color=discord.Color.green())
        embed.description = f"Adding role {role.mention} to {ctx.author.mention}"
        await ctx.reply(embed=embed)
    elif role is None:
        # Memberikan pesan kepada pengguna jika role tidak ditemukan
        embed = discord.Embed(title="Role Not Found", color=discord.Color.red())
        embed.description = "Role not found. Please contact an admin for assistance."
        await ctx.reply(embed=embed)

    os.remove(filename)

    channel_id = 1089946177795010570  # ID channel History Order
    channel = bot.get_channel(channel_id)
    if channel is not None:

        embed = discord.Embed(title=f"Order Number: #{order_number}", color=discord.Color.blue())
        embed.description = f"<:yow:1094927867030290512> Buyer: {ctx.author.mention}\n<:yow:1094927867030290512> Product: {quantity} {product['name']}\n<:yow:1094927867030290512> Total Harga: {total_price} <:emoji_9:1071815138430160997>\n\nTerima Kasih Telah Membeli Product Kami"
        await channel.send(embed=embed)

    product["stock"] = ", ".join(stock[quantity:])
    with open("sell.json", "w") as f:
        json.dump(data, f)

    user["balance"] -= total_price
    with open("database.json", "w") as f:
        json.dump(db, f)

    embed = discord.Embed(title="Success", color=discord.Color.green())
    embed.description = f"Please check your DM\nPlease give reps here <#1069893774936899615>\nex: +rep <@687909626456571955> 2 license"
    await ctx.reply(embed=embed)

@bot.command()
async def send(ctx, mention: discord.Member, code, amount):
    with open("sell.json", "r") as f:
        data = json.load(f)
    product = next((p for p in data if p["code"] == code), None)

    if product is None:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"No products found with code {code}"
        await ctx.reply(embed=embed)
        return

    try:
        amount = int(amount)
    except ValueError:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"The purchase amount must be a number\nExample: .send @user1 code 1"
        await ctx.reply(embed=embed)
        return

    stock = product["stock"].split(", ")
    if len(stock) < amount:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"The product is out of stock"
        await ctx.reply(embed=embed)
        return
    elif not product["stock"]:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"The product is out of stock"
        await ctx.reply(embed=embed)
        return

    message = f"Here your {product['name']}:\n"
    message += "\n"
    message += '\n'.join([line.rstrip(',') for line in stock[:amount]])
    message += "\n"

    filename = f"Arcexy Store.txt"
    with open(filename, "w") as f:
        f.write(message)

    with open(filename, "rb") as f:
        file = discord.File(f)
        embed = discord.Embed(
            title="Successfully",
            description=f"{product['name']} sent to {mention.name}",
            color=discord.Color.green()
        )
        await ctx.reply(embed=embed)
        dm = await mention.create_dm()
        await dm.send(content=f"You have received {amount} {product['name']} from {ctx.author.name}:", file=file)

    os.remove(filename)

    # Menghapus stok yang dikirim ke DM dari file JSON
    product["stock"] = ', '.join(stock[amount:])
    with open("sell.json", "w") as f:
        json.dump(data, f, indent=4)

@bot.command()
async def stock(ctx):
    if ctx.author.id != 687909626456571955:  # ganti id owner
        response = "You can view all stock products here: <#1073782267769524288>"
        await ctx.reply(response)
        return

    with open("sell.json", "r") as f:
        data = json.load(f)

    if len(data) == 0:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"There are no products for sale at this time"
        original_message = await ctx.reply(embed=embed)
    else:
        message = ""
        for product in data:
            stock_count = len(product['stock'].split(',')) if product['stock'] else 0
            message += f"--------------------------------------------\n**{product['name']}**\n<:yow:1094927867030290512> Stock: {stock_count}\n<:yow:1094927867030290512> Code: {product['code']}\n<:yow:1094927867030290512> Price: {product['price']} <:emoji_9:1071815138430160997>\n"

        embed = discord.Embed(title="REALTIME STOCK", color=discord.Color.blue(), description=message)
        original_message = await ctx.reply(embed=embed)

    async def update_stock():
        await asyncio.sleep(5)  # tunggu 5 detik
        while True:
            await asyncio.sleep(5)  # tunggu 5 detik sebelum cek file sell.json
            with open("sell.json", "r") as f:
                data = json.load(f)

            if len(data) == 0:
                embed = discord.Embed(title="Error", color=discord.Color.red())
                embed.description = f"There are no products for sale at this time"
                await original_message.edit(embed=embed)
            else:
                message = ""
                for product in data:
                    stock_count = len(product['stock'].split(',')) if product['stock'] else 0
                    message += f"--------------------------------------------\n**{product['name']}**\n<:yow:1094927867030290512> Stock: {stock_count}\n<:yow:1094927867030290512> Code: {product['code']}\n<:yow:1094927867030290512> Price: {product['price']} <:emoji_9:1071815138430160997>\n"

                embed = discord.Embed(title="REALTIME STOCK", color=discord.Color.blue(), description=message)
                await original_message.edit(embed=embed)

    bot.loop.create_task(update_stock())

@bot.command()
async def depo(ctx):
    with open("depo.json", "r") as f:
        data = json.load(f)

    world = data.get("world", 0)
    owner = data.get("owner", 0)

    message = f"**World: {world}\nOwner: {owner}**"

    embed = discord.Embed(color=discord.Color.green())
    embed.title = message

    await ctx.send(embed=embed)

@bot.command()
async def changeprice(ctx, code: str, price: int):
    if ctx.author.id != 687909626456571955: # ganti dengan owner id lu
        await ctx.reply("You do not have permission to use this command.")
        return

    with open('sell.json', 'r') as f:
        data = json.load(f)

    product = None
    for item in data:
        if item['code'] == code:
            item['price'] = price
            product = item
            break

    if product is not None:
        with open('sell.json', 'w') as f:
            json.dump(data, f, indent=4)

        embed = discord.Embed(
            title="Success",
            description=f"The price of {product['name']} has been changed to {price} <:emoji_9:1071815138430160997>",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)
    else:
        embed = discord.Embed(
            title="Error",
            description=f"Product with code {code} not found",
            color=discord.Color.red()
        )
        await ctx.send(embed=embed)

@bot.command()
async def changeworld(ctx, world: str, owner: str):
    if ctx.author.id != 687909626456571955: # ganti dengan owner id lu
        await ctx.reply("You do not have permission to use this command.")
        return

    with open("depo.json", "r") as f:
        data = json.load(f)
    

    data["world"] = world
    data["owner"] = owner
    
    with open("depo.json", "w") as f:
        json.dump(data, f)
    
    embed = discord.Embed(title="Success replaced the world depo", color=discord.Color.green())
    await ctx.reply(embed=embed)

@bot.command()
async def addbal(ctx, user: commands.MemberConverter, amount: int):

    with open('database.json', 'r') as f:
        data = json.load(f)

    if ctx.author.id != 687909626456571955:
        await ctx.reply("?")
        return

    for entry in data:
        if entry['user'] == user.id:
            
            entry['balance'] += amount
            with open('database.json', 'w') as f:
                json.dump(data, f, indent=4)

            embed = discord.Embed(title="Success", color=discord.Color.green())
            embed.description = f"Added {amount} balance to {user.mention}\nNow {user.display_name} balance is {entry['balance']} <:emoji_9:1071815138430160997>"
            await ctx.reply(embed=embed)
            return

    embed = discord.Embed(title="Error", color=discord.Color.red())
    embed.description = f"User not found"
    await ctx.reply(embed=embed)

async def main():
    await bot.start('MTA3NjMyODc4OTEzNjY0NjE4NQ.G41spH.YvWl0hXXsY2qj-a5HaoALA0psvZbad1dOtkWSc')
    await check_database()

if __name__ == '__main__':
    asyncio.run(main())