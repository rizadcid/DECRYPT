const express = require('express')
const router = express.Router()
const { 
    getDatas,
    setDatas,
    deleteDatas,
    updateDatasName,
    getDatasName,
    getRdpName,
    getRdp,
    addRdp,
    setRdp,
    deleteKategoriRdp,
    deleteRdp,
    updateRdp

} = require('../controllers/dataControllers')

router.route('/nama').get(getDatas).post(setDatas)
router.route('/nama/:namaplayer').get(getDatasName).put(updateDatasName).delete(deleteDatas)
router.route('/rdp').get(getRdp).put(updateRdp).delete(deleteRdp).post(setRdp)
router.route('/rdp/:type').get(getRdpName).delete(deleteKategoriRdp).post(addRdp)
module.exports = router