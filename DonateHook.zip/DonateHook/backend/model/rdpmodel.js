const mongoose = require('mongoose')

const dataSchema = mongoose.Schema({
    type:{
        type: String,
        required: [true,'tambahin tipe!']
    },
    typebarang:{
        type: String,
        required: [true,'tambahin tipe Barang!']
    },
    nama:{
        type: String,
        required: [true,'tambahin namardp!']
    },
    harga:{
        type: Number,
        required: [true,'tambahin jumlahnya!']
    },
    data:[{
        ip:{
            type: String,
            required: [true,'Ip']
        },
        pass:{
            type: String,
            required: [true,'passbang']
        },
    }]

},{
    timestamps: true
})

module.exports = mongoose.model('Rdp',dataSchema)