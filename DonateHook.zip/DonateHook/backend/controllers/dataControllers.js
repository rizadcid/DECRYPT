const asyncHandler = require('express-async-handler')
const Datas = require('../model/model')
const Rdp = require('../model/rdpmodel')
const bodyParser = require('body-parser')

const getDatas = asyncHandler(async (req,res) => {
    const datas = await Datas.find()
    res.status(200).json(datas)
})

const getDatasName = asyncHandler(async (req,res) => {
    
    const datas = await Datas.findOne({ namaplayer: { $eq: req.params.namaplayer }})

    if(!datas){
        res.status(400)
        throw new Error('Kosong Bang')
    }

    res.status(200).json(datas)
})

const setDatas = asyncHandler(async (req,res) => {
    if(!req.body.namaplayer){
        res.status(400)
        throw new Error('Please Add Fields');
    }
    const datas = await Datas.create({
        namaplayer: req.body.namaplayer,
        namabarang: req.body.namabarang,
        jumlah: req.body.jumlah
    })

    res.status(200).json(datas)
})

const updateDatasName = asyncHandler(async (req,res) => {
    const datas = await Datas.findOne({ namaplayer: { $eq: req.params.namaplayer } })
    if(!datas){
        res.status(400)
        throw new Error('Data Kosong')
    }
    
    if(!req.body.dec){
        await Datas.findOneAndUpdate({namaplayer: req.params.namaplayer},{ $inc: { jumlah: parseInt(req.body.jumlah)} })
        const datas = await Datas.findOne({ namaplayer: { $eq: req.params.namaplayer }})
        res.status(200).json(datas)
    }else{
        await Datas.findOneAndUpdate({namaplayer: req.params.namaplayer},{ $inc: { jumlah: parseInt(-req.body.jumlah)} })
        const datas = await Datas.findOne({ namaplayer: { $eq: req.params.namaplayer }})
        res.status(200).json(datas)
    }
})

const deleteDatas = asyncHandler(async (req,res) => {
    const datas = await Datas.findOneAndDelete({namaplayer: {$eq : req.params.namaplayer}})
    
    if(!datas){
        res.status(400)
        throw new Error('Data Kosong')
    }

    await datas.remove()

    res.status(200).json({message: `Data Berhasil Didelete Player : ${req.params.namaplayer}` })
})


const getRdp = asyncHandler(async (req,res) => {
    const rdps = await Rdp.find()
    res.status(200).json(rdps)
})

const getRdpName = asyncHandler(async (req,res) => {
    
    const datas = await Rdp.findOne({ type: { $eq: req.params.type }})

    if(!datas){
        res.status(400)
        throw new Error('Kosong Bang')
    }

    res.status(200).json(datas)
})

const addRdp = asyncHandler(async (req,res) => {
    const rdps = await Rdp.updateOne(
        { 'type': req.params.type },
        { $push: { data: { ip: req.body.ip,pass: req.body.pass} } },
    )

    if(!rdps){
        res.status(400)
        throw new Error('Data Kosong')
    }
    res.status(200).json({type: req.params.type,message:`Success Added RDP With IP ${req.body.ip} And Password ${req.body.pass}`})
})

const setRdp = asyncHandler(async (req,res) => {
    if(!req.body.type || !req.body.nama || !req.body.harga){
        res.status(400)
        throw new Error('All Data mustbe added !!!');
    }
    const datas = await Rdp.create({
        type: req.body.type,
        typebarang: req.body.typebarang,
        nama: req.body.nama,
        harga: req.body.harga,
        data: []
    })

    res.status(200).json(datas)
})

const updateRdp = asyncHandler(async (req,res) => {
    const rdps = await Rdp.findOne({ type: { $eq: req.body.daritype } })
    if(!rdps){
        res.status(400)
        throw new Error('Data Kosong')
    }
    const updatedrpds = await Rdp.findOneAndUpdate({type: req.body.daritype },{ type: req.body.ketype ,typebarang: req.body.typebarang,nama: req.body.nama,harga: req.body.harga})
    res.status(200).json(updatedrpds)
})


const deleteKategoriRdp = asyncHandler(async (req,res) => {
    const rdps = await Rdp.findOneAndDelete({type: {$eq : req.params.type}})
    
    if(!rdps){
        res.status(400)
        throw new Error('Data Kosong')
    }
    //await rdps.remove()
    res.status(200).json({namardp: req.params.type,message:`Berhasil Menghapus Kategori ${req.params.type}`})

})

const deleteRdp = asyncHandler(async (req,res) => {
    //const rdps = await Rdp.findOneAndDelete({namardp: {$eq : req.params.namardp}})
    const rdps = await Rdp.updateOne(
        { type: req.body.type },
        { $pull: { data: { ip: req.body.ip } } },
        { upsert: true}
    )
    if(!rdps){
        res.status(400)
        throw new Error('Data Kosong')
    }
    //await rdps.remove()
    res.status(200).json({type: req.body.type,message:`Success Deleted RDP With IP ${req.body.ip}`})
})


module.exports = {
    getDatas,
    setDatas,
    deleteDatas,
    updateDatasName,
    getDatasName,
    getRdp,
    addRdp,
    getRdpName,
    setRdp,
    updateRdp,
    deleteKategoriRdp,
    deleteRdp
}