const express = require('express')
const dotenv = require('dotenv').config()
const cors = require('cors')
const colors = require('colors')
const connectDB = require('./backend/config/db')
const {errorHandler} = require('./backend/middleware/errorMiddleware')
const port = process.env.PORT || 3000
const app = express()

connectDB()

app.use(express.json())
app.use(express.urlencoded({extended: false}))

app.use('/api/data',require('./backend/routes/dataRoutes'))

app.use(errorHandler)

app.listen(port, () => console.log(`Example app listening on port ${port}!`))