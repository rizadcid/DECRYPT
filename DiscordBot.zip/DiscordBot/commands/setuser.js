const { SlashCommandBuilder: slashCommandBuilder } = require('@discordjs/builders'),
  { MessageEmbed: messBuilder } = require('discord.js'),
  playerSchema = require('../model/playerSchema')
module.exports = {
  data: new slashCommandBuilder()
    .setName('setuser')
    .setDescription('Set Your Growid in Growtopia')
    .addStringOption((growId) =>
      growId
        .setName('player')
        .setDescription('Regist Player In DataBase')
        .setRequired(true)
    ),
  async execute(interaction) {
    const playerSchemaFindOneDcId = await playerSchema.findOne({
        discordid: { $eq: interaction.user.id },
      }),
      playerSchemaFindOnePlayerName = await playerSchema.findOne({
        namaplayer: {
          $eq: interaction.options.getString('player').toUpperCase(),
        },
      })
    if (playerSchemaFindOnePlayerName) {
      interaction.reply({
        content:
          interaction.options.getString('player').toUpperCase() +
          ' UDAH ADA TOLOL! ',
        ephemeral: true,
      })
      return
    }
    if (!playerSchemaFindOneDcId) {
      await playerSchema.create({
        discordid: interaction.user.id,
        namaplayer: interaction.options.getString('player').toUpperCase(),
        namabarang: 'World Lock',
        jumlah: 0,
      })
      interaction.reply({
        content:
          'ADDED GROWID SET TO ' +
          interaction.options.getString('player').toUpperCase(),
        ephemeral: true,
      })
      return
    }
    await playerSchema.findOneAndUpdate(
      { discordid: interaction.user.id },
      { namaplayer: interaction.options.getString('player').toUpperCase() }
    )
    const growIdSetToEmbed = new messBuilder()
      .setColor('#0099ff')
      .setTitle(
        'GROWID SET TO ' + interaction.options.getString('player').toUpperCase()
      )
    await interaction.reply({
      embeds: [growIdSetToEmbed],
      ephemeral: true,
    })
  },
}
