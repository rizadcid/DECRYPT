const { SlashCommandBuilder: slashBuilder } = require('@discordjs/builders'),
  { MessageEmbed: messEmbed } = require('discord.js'),
  RdpSchema = require('../model/rdpSchema'),
  PlayerSchema = require('../model/playerSchema'),
  HistorySchema = require('../model/HistorySchema')
module.exports = {
  data: new slashBuilder()
    .setName('buy')
    .setDescription('Buy Here!')
    .addStringOption((productType) =>
      productType.setName('kode').setDescription('Tipe Produk').setRequired(true)
    ),
  async execute(interaction) {
    const findPlayerSchema = await PlayerSchema.findOne({
      discordid: { $eq: interaction.user.id },
    })
    if (!findPlayerSchema) {
      interaction.reply({
        content: 'Maaf Kamu Belum Setuser Growid /setuser (namabot)',
        ephemeral: true,
      })
      return
    }
    const findRdpSchema = await RdpSchema.findOne({
        type: interaction.options.getString('kode').toUpperCase(),
      }),
      foundRdpSchema = await RdpSchema.findOne(
        { type: interaction.options.getString('kode').toUpperCase() },
        {
          data: 1,
          _id: 0,
        }
      ),
      foundPlayerSchema = await PlayerSchema.findOne({
        discordid: { $eq: interaction.user.id },
      })
    if (!findRdpSchema) {
      interaction.reply({
        content: 'Kode Tidak ditemukan cari di /stok',
        ephemeral: true,
      })
      return
    }
    let stringFindRdpSchema = await JSON.stringify(findRdpSchema),
      parseStringFindRdpSchema = await JSON.parse(stringFindRdpSchema),
      stringFindRdpSchema2 = await JSON.stringify(foundRdpSchema),
      parseStringFindRdpSchema2 = await JSON.parse(stringFindRdpSchema2)
    if (parseStringFindRdpSchema.data.length === 0) {
      interaction.reply({
        content: 'Stock **' + parseStringFindRdpSchema.nama + '** Habis',
        ephemeral: true,
      })
      return
    }
    let stringFindPlayerSchema = await JSON.stringify(foundPlayerSchema),
      parseStringFindPlayerSchema = await JSON.parse(stringFindPlayerSchema)
    const toStringParseStringFindPlayerSchema = await parseStringFindPlayerSchema.jumlah.toString()
    if (toStringParseStringFindPlayerSchema < parseStringFindRdpSchema.harga) {
      interaction.reply({
        content:
          process.env.WL + ' Kurang ' + (toStringParseStringFindPlayerSchema - parseStringFindRdpSchema.harga) + ' ',
        ephemeral: true,
      })
      return
    }
    await RdpSchema.updateOne(
      { type: interaction.options.getString('kode').toUpperCase() },
      { $pop: { data: -1 } }
    )
    await PlayerSchema.findOneAndUpdate(
      { discordid: interaction.user.id },
      { $inc: { jumlah: -parseStringFindRdpSchema.harga } }
    )
    const newEmbedRequest = new messEmbed()
      .setColor('#0099ff')
      .setTitle(process.env.WL + ' : ' + (toStringParseStringFindPlayerSchema - parseStringFindRdpSchema.harga))
      .setAuthor({
        name: interaction.user.username,
        iconURL: interaction.user.displayAvatarURL(),
      })
      .setTimestamp()
      .setFooter({
        text: 'Requested by ' + interaction.user.username,
        iconURL: interaction.user.displayAvatarURL(),
      })
      .addField(
        'Berhasil Membeli **' +
          parseStringFindRdpSchema.nama +
          '**\nDengan Harga : **' +
          parseStringFindRdpSchema.harga +
          '** ' +
          process.env.WL +
          '\n',
        '\u200B',
        false
      )
      .addField(
        'SCRIPT BOT AUTO SEND BY RIFDI',
        true
      )
    for (var rdpSchema2Data in parseStringFindRdpSchema2.data[0]) {
      newEmbedRequest.addField(
        '**' +
          rdpSchema2Data.toUpperCase() +
          '** : ||' +
          parseStringFindRdpSchema2.data[0][rdpSchema2Data] +
          '||',
        '\u200B',
        false
      )
    }
    newEmbedRequest.addField(
      'SCRIPT BOR AUTO SEND BY RIFDI',
      '\u200B',
      true
    )
    newEmbedRequest.setImage(process.env.GAMBARBANNER)
    const stringifyParseRdpSchemaData = JSON.stringify(parseStringFindRdpSchema2.data[0])
    await interaction.reply(interaction.user.username + ' DATA SEND TO DM ')
    await interaction.user.send({
      embeds: [newEmbedRequest],
      ephemeral: true,
    })
    interaction.member.roles.cache.has(process.env.NAME_ROLE_TOBUYER) === false &&
      (await interaction.member.roles.add(process.env.NAME_ROLE_TOBUYER))
    IsCount = await HistorySchema.findOne({ no: { $eq: 0 } })
    !IsCount &&
      (await HistorySchema.create({
        no: 0,
        discordid: 1,
        namaplayer: 'null',
        typebarang: 'null',
        namabarang: 'null',
        hargabarang: 1,
        data: 'null',
        jumlah: 1,
      }))
    countsz = await HistorySchema.aggregate([
      {
        $group: {
          _id: '',
          last: { $max: '$no' },
        },
      },
    ])
    const orderEmbed = new messEmbed()
      .setColor('#0099ff')
      .setTitle(
        process.env.ARROW + ' **#Order Number** : ' + (countsz[0].last + 1)
      )
      .setTimestamp()
      .setFooter({ text: 'Time' })
      .addField(
        '\u200B',
        'Member : **' +
          ('<@' + interaction.user.id + '>') +
          '**\n' +
          process.env.ARROW +
          ' Kode Produk : **' +
          interaction.options.getString('kode').toUpperCase() +
          '** \n' +
          process.env.ARROW +
          ' Berhasil Membeli **' +
          parseStringFindRdpSchema.nama +
          '**\n' +
          process.env.ARROW +
          ' Dengan Harga : **' +
          parseStringFindRdpSchema.harga +
          '** ' +
          process.env.WL +
          '\n',
        true
      )
      .setImage(process.env.GAMBARBANNER)
    await interaction.guild.channels.cache.get(process.env.HISTORY_CHANNEL).send({
      embeds: [orderEmbed],
      ephemeral: false,
    })
    dataz = await PlayerSchema.findOne({ discordid: { $eq: interaction.user.id } })
    await HistorySchema.create({
      no: countsz[0].last + 1,
      discordid: interaction.user.id,
      namaplayer: dataz.namaplayer,
      typebarang: interaction.options.getString('kode').toUpperCase(),
      namabarang: parseStringFindRdpSchema.nama,
      hargabarang: parseStringFindRdpSchema.harga,
      data: stringifyParseRdpSchemaData,
      jumlah: 1,
    })
  },
}
