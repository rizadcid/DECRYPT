const { SlashCommandBuilder: slashBuilder } = require('@discordjs/builders'),
  { MessageEmbed: messEmbed } = require('discord.js'),
  _0x5a5403 = require('../model/rdpSchema'),
  _0x355512 = require('../model/playerSchema')
module.exports = {
  data: new slashBuilder()
    .setName('add')
    .setDescription('Tambah Data')
    .addStringOption((addCode) =>
      addCode.setName('kode').setDescription('Tambah Kode').setRequired(true)
    )
    .addStringOption((addIpAddress) =>
      addIpAddress
        .setName('ip')
        .setDescription('Tambah Ip Adress')
        .setRequired(true)
    )
    .addStringOption((addUserPassword) =>
      addUserPassword
        .setName('user_password')
        .setDescription('Tambah User dan Password')
        .setRequired(true)
    ),
  async execute(interaction) {
    if (interaction.member.roles.cache.has(process.env.OWNERID) === false) {
      await interaction.reply({
        content: 'No Admin Role',
        ephemeral: true,
      })
      console.log(
        interaction.user.username +
          ' : Role Owner :' +
          interaction.member.roles.cache.has(process.env.OWNERID)
      )
      console.log(
        interaction.user.username +
          ' : Role CO Owner :' +
          interaction.member.roles.cache.has(process.env.OWNERID)
      )
      return
    } else {
      const _0xa9ecc8 = await _0x5a5403.updateOne(
          { type: interaction.options.getString('kode').toUpperCase() },
          {
            $push: {
              data: {
                $each: [
                  {
                    Ip: '' + interaction.options.getString('ip'),
                    Password: '' + interaction.options.getString('user_password'),
                  },
                ],
                $slice: -100,
              },
            },
          }
        ),
        getInfoEmbed = new messEmbed()
          .setColor('RANDOM')
          .setTitle('INFO\nAdded\n')
          .setAuthor({
            name: interaction.user.username,
            iconURL: interaction.user.displayAvatarURL(),
          })
          .addField(
            '\u200B',
            '**KODE**   : ' +
              interaction.options.getString('kode').toUpperCase() +
              '\n**Ip Address**   : ' +
              interaction.options.getString('ip') +
              ' \n**Password**    : ' +
              interaction.options.getString('user_password'),
            true
          )
          .setTimestamp()
          .setFooter({
            text: 'Requested by ' + interaction.user.username,
            iconURL: interaction.user.displayAvatarURL(),
          })
      _0xa9ecc8
      await interaction.reply({
        embeds: [getInfoEmbed],
        ephemeral: true,
      })
    }
  },
}
