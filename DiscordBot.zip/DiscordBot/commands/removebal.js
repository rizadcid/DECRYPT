const { SlashCommandBuilder: slashBuilder } = require('@discordjs/builders'),
  { MessageEmbed: messEmbed } = require('discord.js')
module.exports = {
  data: new slashBuilder()
    .setName('removebalance')
    .setDescription('Kurang Balance')
    .addStringOption((addNamaplayer) =>
      addNamaplayer.setName('namaplayer').setDescription('Tambah Nama Player').setRequired(true)
    )
    .addStringOption((addJumlah) =>
      addJumlah
        .setName('jumlahbalance')
        .setDescription('Jumlah Remove Balance')
        .setRequired(true)
    ),
  async execute(interaction) {
    if (interaction.member.roles.cache.has(process.env.OWNERID) === false) {
      await interaction.reply({
        content: 'No Admin Role',
        ephemeral: true,
      })
      console.log(
        interaction.user.username +
          ' : Role Owner :' +
          interaction.member.roles.cache.has(process.env.OWNERID)
      )
      console.log(
        interaction.user.username +
          ' : Role CO Owner :' +
          interaction.member.roles.cache.has(process.env.OWNERID)
      )
      return
    } else {
      const someData = {
         jumlah: interaction.options.getString('jumlahbalance'),
         dec: 'yes'
      };
      const url = 'http://localhost:3000/api/data/nama/' + interaction.options.getString('namaplayer')
      const putMethod = {
 method: 'PUT', // Method itself
 headers: {
  'Content-type': 'application/json' // Indicates the content 
 },
 body: JSON.stringify(someData)  // We send data in JSON format
}

// make the HTTP put request using fetch api
fetch(url, putMethod)
.then(response => response.json())
.then(data => console.log(data))
.catch(err => console.log(err))
        getInfoEmbed = new messEmbed()
          .setColor('RANDOM')
          .setTitle('INFO\nRemoved\n')
          .setAuthor({
            name: interaction.user.username,
            iconURL: interaction.user.displayAvatarURL(),
          })
          .addField(
            '\u200B',
            '**NAMA PLAYER**   : ' +
              interaction.options.getString('namaplayer').toUpperCase() +
              '\n**JUMLAH BALANCE**   : ' +
              -interaction.options.getString('jumlahbalance'),
            true
          )
          .setTimestamp()
          .setFooter({
            text: 'Requested by ' + interaction.user.username,
            iconURL: interaction.user.displayAvatarURL(),
          })
      await interaction.reply({
        embeds: [getInfoEmbed],
        ephemeral: true,
      })
    }
  },
}