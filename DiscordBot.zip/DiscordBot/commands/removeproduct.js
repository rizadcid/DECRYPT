const { SlashCommandBuilder: slashBuilder } = require('@discordjs/builders'),
  { MessageEmbed: messEmbed } = require('discord.js')
module.exports = {
  data: new slashBuilder()
    .setName('removeproduct')
    .setDescription('Tambah Data')
    .addStringOption((addCodee) =>
      addCodee.setName('kode').setDescription('Tambah kodee').setRequired(true)
    ),
  async execute(interaction) {
    if (interaction.member.roles.cache.has(process.env.OWNERID) === false) {
      await interaction.reply({
        content: 'No Admin Role',
        ephemeral: true,
      })
      console.log(
        interaction.user.username +
          ' : Role Owner :' +
          interaction.member.roles.cache.has(process.env.OWNERID)
      )
      console.log(
        interaction.user.username +
          ' : Role CO Owner :' +
          interaction.member.roles.cache.has(process.env.OWNERID)
      )
      return
    } else {
      const url = 'http://localhost:3000/api/data/rdp/' + interaction.options.getString('kode').toUpperCase()
      const putMethod = {
 method: 'DELETE', // Method itself
 headers: {
  'Content-type': 'application/json' // Indicates the content 
 }
}

// make the HTTP put request using fetch api
fetch(url, putMethod)
.then(response => response.json())
.then(data => console.log(data)) // Manipulate the data retrieved back, if we want to do something with it
.catch(err => console.log(err))
        getInfoEmbed = new messEmbed()
          .setColor('RANDOM')
          .setTitle('INFO\nRemoved\n')
          .setAuthor({
            name: interaction.user.username,
            iconURL: interaction.user.displayAvatarURL(),
          })
          .addField(
            '\u200B',
            '**kode**   : ' +
              interaction.options.getString('kode').toUpperCase(),
            true
          )
          .setTimestamp()
          .setFooter({
            text: 'Requested by ' + interaction.user.username,
            iconURL: interaction.user.displayAvatarURL(),
          })
      await interaction.reply({
        embeds: [getInfoEmbed],
        ephemeral: true,
      })
    }
  },
}