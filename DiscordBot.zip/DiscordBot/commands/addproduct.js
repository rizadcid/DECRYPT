const { SlashCommandBuilder: slashBuilder } = require('@discordjs/builders'),
  { MessageEmbed: messEmbed } = require('discord.js')
module.exports = {
  data: new slashBuilder()
    .setName('addproduct')
    .setDescription('Tambah Data')
    .addStringOption((addCodee) =>
      addCodee.setName('kodee').setDescription('Tambah kodee').setRequired(true)
    )
    .addStringOption((addNama) =>
      addNama
        .setName('nama')
        .setDescription('Tambah nama')
        .setRequired(true)
    )
    .addStringOption((addHarga) =>
      addHarga
        .setName('harga')
        .setDescription('Tambah Harga')
        .setRequired(true)
    ),
  async execute(interaction) {
    if (interaction.member.roles.cache.has(process.env.OWNERID) === false) {
      await interaction.reply({
        content: 'No Admin Role',
        ephemeral: true,
      })
      console.log(
        interaction.user.username +
          ' : Role Owner :' +
          interaction.member.roles.cache.has(process.env.OWNERID)
      )
      console.log(
        interaction.user.username +
          ' : Role CO Owner :' +
          interaction.member.roles.cache.has(process.env.OWNERID)
      )
      return
    } else {
      const someData = {
         type: interaction.options.getString('kodee'),
         typebarang: 'RDP',
         nama: interaction.options.getString('nama'),
         harga: interaction.options.getString('harga')
      };
      const url = 'http://localhost:3000/api/data/rdp/'
      const putMethod = {
 method: 'POST', // Method itself
 headers: {
  'Content-type': 'application/json' // Indicates the content 
 },
 body: JSON.stringify(someData)  // We send data in JSON format
}

// make the HTTP put request using fetch api
fetch(url, putMethod)
.then(response => response.json())
.then(data => console.log(data)) // Manipulate the data retrieved back, if we want to do something with it
.catch(err => console.log(err))
        getInfoEmbed = new messEmbed()
          .setColor('RANDOM')
          .setTitle('INFO\nAdded\n')
          .setAuthor({
            name: interaction.user.username,
            iconURL: interaction.user.displayAvatarURL(),
          })
          .addField(
            '\u200B',
            '**kode**   : ' +
              interaction.options.getString('kodee').toUpperCase() +
              '\n**Nama**   : ' +
              interaction.options.getString('nama') +
              ' \n**Harga**    : ' +
              interaction.options.getString('harga'),
            true
          )
          .setTimestamp()
          .setFooter({
            text: 'Requested by ' + interaction.user.username,
            iconURL: interaction.user.displayAvatarURL(),
          })
      await interaction.reply({
        embeds: [getInfoEmbed],
        ephemeral: true,
      })
    }
  },
}