const { SlashCommandBuilder: slashCommandBuilder } = require('@discordjs/builders'),
  { MessageEmbed: messageEmbed } = require('discord.js')
module.exports = {
  data: new slashCommandBuilder().setName('help').setDescription('See Commands in here'),
  async execute(interaction) {
    const helpEmbed = new messageEmbed()
      .setColor('#0099ff')
      .setTitle('Help Command')
      .setAuthor({
        name: interaction.user.username,
        iconURL: interaction.user.displayAvatarURL(),
      })
      .addField(
        'List Commands',
        '\n**\n/setuser set akun growtopia\n/stok Liat List Produk\n/buy (KODE) Membeli Produk\n/BALANCE Melihat Saldo Akun\n/ping Test Ping\n/echo (msg) Bot Follow User**',
        true
      )
      .setTimestamp()
      .setImage(process.env.GAMBARBANNER)
      .setFooter({
        text: 'Requested by ' + interaction.user.username,
        iconURL: interaction.user.displayAvatarURL(),
      })
    await interaction.reply({
      embeds: [helpEmbed],
      ephemeral: false,
    })
  },
}
