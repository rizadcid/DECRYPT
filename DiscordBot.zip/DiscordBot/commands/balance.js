const { SlashCommandBuilder: _0x12f06b } = require('@discordjs/builders'),
  { MessageEmbed: _0x1a7ddd } = require('discord.js'),
  _0x4497cc = require('../model/playerSchema')
module.exports = {
  data: new _0x12f06b().setName('balance').setDescription('Check Balance!'),
  async execute(_0x2b80df) {
    const _0x16b814 = await _0x4497cc.findOne({
      discordid: { $eq: _0x2b80df.user.id },
    })
    if (!_0x16b814) {
      _0x2b80df.reply({
        content: 'Set Growid /setuser <namaplayer>',
        ephemeral: true,
      })
      return
    }
    let _0x483d8f = await JSON.stringify(_0x16b814),
      _0x573124 = await JSON.parse(_0x483d8f)
    const _0x22424d = new _0x1a7ddd()
      .setColor('#0099ff')
      .setTitle('Saldo Di Bank ' + _0x2b80df.guild.name)
      .setAuthor({
        name: _0x2b80df.user.username,
        iconURL: _0x2b80df.user.displayAvatarURL(),
      })
      .addField(
        '\u200B',
        '**' + _0x573124.jumlah.toString() + '**  ' + process.env.WL,
        true
      )
      .setImage(process.env.GAMBARBANNER)
      .setTimestamp()
      .setFooter({
        text: 'Requested by ' + _0x2b80df.user.username,
        iconURL: _0x2b80df.user.displayAvatarURL(),
      })
    await _0x2b80df.reply({
      embeds: [_0x22424d],
      ephemeral: false,
    })
  },
}
