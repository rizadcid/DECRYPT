const { SlashCommandBuilder: slashCommandBuilder } = require('@discordjs/builders'),
  { MessageEmbed: messEmbed } = require('discord.js'),
  rdpSchema = require('../model/rdpSchema')
module.exports = {
  data: new slashCommandBuilder().setName('stock').setDescription('Stock Shop Here!'),
  async execute(interaction) {
    const aggreRdpSchema = await rdpSchema.aggregate([
      {
        $group: {
          _id: '$typebarang',
          count: { $count: {} },
        },
      },
      { $sort: { _id: 1 } },
    ])
    async function parsStringFunc(parsStringFuncArg) {
      const argStringi = await JSON.stringify(parsStringFuncArg),
        argStringiParse = await JSON.parse(argStringi)
      return argStringiParse
    }
    async function getDataFunc(getDataFuncArg) {
      const rdpSchemaAggre = await rdpSchema.aggregate([
          { $match: { typebarang: getDataFuncArg } },
          {
            $project: {
              _id: 0,
              sum: 1,
              typebarang: '$typebarang',
              namatipe: '$type',
              desc: '$nama',
              harga: '$harga',
              stok: { $size: '$data' },
            },
          },
          { $sort: { namatipe: 1 } },
        ]),
        parseRdpSchema = await parsStringFunc(rdpSchemaAggre)
      return parseRdpSchema
    }
    const parseRdpSchema2 = await parsStringFunc(aggreRdpSchema),
      getDataRDP = await getDataFunc('RDP')
    console.log(parseRdpSchema2)
    const newEmbed = new messEmbed()
      .setColor('#0099ff')
      .setTitle(
        'SCRIPT BOT AUTO SEND BY RIFDI'
      )
      .setAuthor({
        name: interaction.user.username,
        iconURL: interaction.user.displayAvatarURL(),
      })
      .setTimestamp()
      .setImage(process.env.GAMBARBANNER)
      .setFooter({
        text: 'Requested by ' + interaction.user.username,
        iconURL: interaction.user.displayAvatarURL(),
      })
    for (let index = 0; index < parseRdpSchema2[0].count; index++) {
      newEmbed.addField(
        '\u200B',
        process.env.ARROW +
          ' Kode : **' +
          getDataRDP[index].namatipe.toString() +
          '**\n' +
          process.env.ARROW +
          ' Nama: **' +
          getDataRDP[index].desc.toString() +
          '**\n' +
          process.env.ARROW +
          ' Stok: **' +
          getDataRDP[index].stok.toString() +
          '**\n' +
          process.env.ARROW +
          ' Harga: **' +
          getDataRDP[index].harga.toString() +
          '** ' +
          process.env.WL,
        true
      )
    }
    await interaction.reply({
      embeds: [newEmbed],
      ephemeral: false,
    })
  },
}
